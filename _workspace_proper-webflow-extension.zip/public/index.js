// Cloudinary configuration
const CLOUD_NAME = 'dzrw8nopf';
const API_KEY = '631242939362623';

// Wait for DOM to be ready
document.addEventListener('DOMContentLoaded', function() {
    console.log('HOIBF Cloudinary Extension loaded in Webflow');
    
    // Set up the open library button
    const openButton = document.getElementById('open-library');
    if (openButton) {
        openButton.addEventListener('click', openMediaLibrary);
    }
});

// Open Cloudinary Media Library
function openMediaLibrary() {
    console.log('Opening Cloudinary Media Library...');
    
    try {
        // Create media library widget
        const mediaLibrary = cloudinary.createMediaLibrary(
            {
                cloud_name: CLOUD_NAME,
                api_key: API_KEY,
                button_class: 'cloudinary-button',
                button_caption: 'Select Images',
                remove_header: false,
                max_files: 10,
                inline_container: null,
                default_transformations: [[{quality: 'auto', fetch_format: 'auto'}]]
            },
            {
                insertHandler: function(data) {
                    console.log('Assets selected:', data);
                    handleSelectedAssets(data.assets);
                }
            }
        );
        
        // Show the media library
        mediaLibrary.show();
        
    } catch (error) {
        console.error('Error opening media library:', error);
        alert('Error opening media library. Please check the console for details.');
    }
}

// Handle selected assets
function handleSelectedAssets(assets) {
    const assetsSection = document.getElementById('selected-assets');
    const assetsList = document.getElementById('assets-list');
    
    // Show the assets section
    assetsSection.style.display = 'block';
    
    // Clear previous assets
    assetsList.innerHTML = '';
    
    // Add each asset to the grid
    assets.forEach(asset => {
        const card = createAssetCard(asset);
        assetsList.appendChild(card);
    });
    
    // Scroll to assets section
    assetsSection.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
}

// Create asset card element
function createAssetCard(asset) {
    const card = document.createElement('div');
    card.className = 'asset-card';
    
    const img = document.createElement('img');
    img.className = 'asset-image';
    img.src = asset.secure_url;
    img.alt = asset.public_id || 'Cloudinary asset';
    
    const info = document.createElement('div');
    info.className = 'asset-info';
    
    const urlDiv = document.createElement('div');
    urlDiv.className = 'asset-url';
    urlDiv.textContent = asset.secure_url;
    
    const copyButton = document.createElement('button');
    copyButton.className = 'copy-button';
    copyButton.textContent = 'Copy URL';
    copyButton.onclick = function() {
        copyToClipboard(asset.secure_url, copyButton);
    };
    
    info.appendChild(urlDiv);
    info.appendChild(copyButton);
    card.appendChild(img);
    card.appendChild(info);
    
    return card;
}

// Copy URL to clipboard
function copyToClipboard(text, button) {
    navigator.clipboard.writeText(text).then(() => {
        const originalText = button.textContent;
        button.textContent = '✓ Copied!';
        
        setTimeout(() => {
            button.textContent = originalText;
        }, 2000);
    }).catch(err => {
        console.error('Failed to copy:', err);
        alert('Failed to copy URL');
    });
}